package com.example.configure_perangkatmodul6

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
